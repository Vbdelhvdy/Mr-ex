require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");
const { Pool } = require("pg");

const app = express();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.PG_POOL_MAX || 10),
  connectionTimeoutMillis: 8000,
  idleTimeoutMillis: 30000,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : undefined
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function makeSlug(){ return crypto.randomBytes(6).toString("base64url"); }
function cleanName(v){ return String(v || "").trim().replace(/\s+/g," ").slice(0,100); }

let schemaReady = null;
function ensureSchema(){
  if (!process.env.DATABASE_URL) return Promise.reject(new Error("DATABASE_URL غير مضبوط في Vercel"));
  if (!schemaReady) {
    schemaReady = (async () => {
      const schema = fs.readFileSync(path.join(__dirname,"schema.sql"),"utf8");
      const client = await pool.connect();
      try {
        // Serialize schema initialization across separate Vercel serverless instances.
        await client.query("BEGIN");
        await client.query("SELECT pg_advisory_xact_lock(hashtext('mr_exam_schema_init'))");
        await client.query(schema);
        await client.query("COMMIT");
      } catch (err) {
        try { await client.query("ROLLBACK"); } catch (_) {}
        throw err;
      } finally {
        client.release();
      }
    })().catch(err => { schemaReady = null; throw err; });
  }
  return schemaReady;
}

app.get("/api/health", async (req,res)=>{
  try { await ensureSchema(); await pool.query("SELECT 1"); res.json({ok:true}); }
  catch(e){ res.status(500).json({ok:false,error:"قاعدة البيانات غير متصلة: "+e.message}); }
});

app.get("/api/admin/exams", async (req,res)=>{
  try{
    await ensureSchema();
    const r=await pool.query(`SELECT e.id,e.title,e.duration_minutes,e.slug,e.status,e.created_at,
      COUNT(DISTINCT q.id)::int question_count
      FROM exams e LEFT JOIN questions q ON q.exam_id=e.id
      GROUP BY e.id ORDER BY e.created_at DESC`);
    res.json(r.rows);
  }catch(e){ res.status(500).json({error:"تعذر تحميل الامتحانات: "+e.message}); }
});

app.get("/api/admin/attempts", async (req,res)=>{
  try{
    await ensureSchema();
    const search=String(req.query.search||"").trim().slice(0,100);
    const status=String(req.query.status||"all");
    const r=await pool.query(`SELECT a.id AS attempt_id,a.student_name,e.title AS exam_title,
      a.started_at,a.submitted_at,a.score,a.total_points,a.percentage,a.submit_reason,
      CASE WHEN a.submitted_at IS NOT NULL THEN 'completed' ELSE 'in_progress' END AS status,
      CASE WHEN a.submitted_at IS NOT NULL THEN GREATEST(0,ROUND(EXTRACT(EPOCH FROM (a.submitted_at-a.started_at))))::int
           ELSE GREATEST(0,ROUND(EXTRACT(EPOCH FROM (NOW()-a.started_at))))::int END AS duration_seconds
      FROM attempts a JOIN exams e ON e.id=a.exam_id
      WHERE ($1='' OR a.student_name ILIKE '%'||$1||'%' OR e.title ILIKE '%'||$1||'%')
        AND ($2='all' OR ($2='completed' AND a.submitted_at IS NOT NULL) OR ($2='in_progress' AND a.submitted_at IS NULL))
      ORDER BY a.started_at DESC LIMIT 500`,[search,status]);
    res.json(r.rows);
  }catch(e){res.status(500).json({error:"تعذر تحميل سجل الامتحانات: "+e.message});}
});

app.post("/api/admin/exams", async (req,res)=>{
  let client;
  try{
    await ensureSchema();
    const title=String(req.body?.title||"").trim().slice(0,200);
    const duration=Number(req.body?.durationMinutes);
    const questions=Array.isArray(req.body?.questions)?req.body.questions:[];
    if(!title || !Number.isInteger(duration) || duration<1 || duration>1440 || !questions.length)
      return res.status(400).json({error:"بيانات الامتحان غير مكتملة"});
    client=await pool.connect();
    await client.query("BEGIN");
    const slug=makeSlug();
    const e=await client.query("INSERT INTO exams(title,duration_minutes,slug) VALUES($1,$2,$3) RETURNING id,title,duration_minutes,slug,status",[title,duration,slug]);
    for(let i=0;i<questions.length;i++){
      const q=questions[i]||{};
      const type=q.type==="true_false"?"true_false":"mcq";
      const text=String(q.text||"").trim().slice(0,1000);
      if(!text) throw new Error(`نص السؤال رقم ${i+1} ناقص`);
      let options,correct;
      if(type==="true_false"){
        options=["صح","غلط"];
        correct=q.correctAnswer==="غلط"?"غلط":"صح";
      }else{
        options=Array.isArray(q.options)?q.options.map(x=>String(x||"").trim().slice(0,300)).slice(0,4):[];
        correct=String(q.correctAnswer||"").trim();
        if(options.length!==4 || options.some(x=>!x) || !options.includes(correct)) throw new Error(`بيانات الاختيارات في السؤال رقم ${i+1} غير صحيحة`);
      }
      await client.query("INSERT INTO questions(exam_id,position,type,question_text,options,correct_answer,points) VALUES($1,$2,$3,$4,$5,$6,1)",[e.rows[0].id,i+1,type,text,JSON.stringify(options),correct]);
    }
    await client.query("COMMIT");
    res.json({ok:true,exam:e.rows[0],url:`/exam/${slug}`});
  }catch(err){
    if(client) try{await client.query("ROLLBACK")}catch{}
    res.status(500).json({error:"تعذر إنشاء الامتحان: "+err.message});
  }finally{ if(client) client.release(); }
});

app.patch("/api/admin/exams/:id/status", async (req,res)=>{
  try{ await ensureSchema(); const status=req.body?.status==="closed"?"closed":"open"; await pool.query("UPDATE exams SET status=$1 WHERE id=$2",[status,req.params.id]); res.json({ok:true}); }
  catch(e){ res.status(500).json({error:e.message}); }
});
app.delete("/api/admin/exams/:id", async (req,res)=>{
  try{ await ensureSchema(); await pool.query("DELETE FROM exams WHERE id=$1",[req.params.id]); res.json({ok:true}); }
  catch(e){ res.status(500).json({error:e.message}); }
});

app.get("/api/exams/:slug", async (req,res)=>{
  try{
    await ensureSchema();
    const e=await pool.query("SELECT id,title,duration_minutes,slug,status FROM exams WHERE slug=$1",[req.params.slug]);
    if(!e.rowCount) return res.status(404).json({error:"الامتحان غير موجود"});
    if(e.rows[0].status!=="open") return res.status(403).json({error:"الامتحان مغلق"});
    const q=await pool.query("SELECT id,position,type,question_text,options,points FROM questions WHERE exam_id=$1 ORDER BY position",[e.rows[0].id]);
    res.json({exam:e.rows[0],questions:q.rows});
  }catch(e){res.status(500).json({error:"تعذر تحميل الامتحان: "+e.message});}
});

app.post("/api/exams/:slug/start", async (req,res)=>{
  try{
    await ensureSchema();
    const name=cleanName(req.body?.studentName);
    if(name.length<2) return res.status(400).json({error:"اكتب اسم الطالب"});
    const e=await pool.query("SELECT id,duration_minutes,status FROM exams WHERE slug=$1",[req.params.slug]);
    if(!e.rowCount || e.rows[0].status!=="open") return res.status(404).json({error:"الامتحان غير متاح"});
    const id=crypto.randomUUID();
    const r=await pool.query("SELECT COALESCE(SUM(points),0)::int total FROM questions WHERE exam_id=$1",[e.rows[0].id]);
    const a=await pool.query("INSERT INTO attempts(id,exam_id,student_name,total_points) VALUES($1,$2,$3,$4) RETURNING id,started_at",[id,e.rows[0].id,name,r.rows[0].total]);
    const expiresAt=new Date(new Date(a.rows[0].started_at).getTime()+e.rows[0].duration_minutes*60000);
    res.json({attemptId:id,startedAt:a.rows[0].started_at,expiresAt});
  }catch(e){res.status(500).json({error:"تعذر بدء الامتحان: "+e.message});}
});

app.get("/api/attempts/:id", async (req,res)=>{
  try{
    await ensureSchema();
    const r=await pool.query(`SELECT a.id,a.exam_id,a.student_name,a.started_at,a.submitted_at,a.score,a.total_points,a.percentage,a.submit_reason,e.slug,e.duration_minutes,e.title
      FROM attempts a JOIN exams e ON e.id=a.exam_id WHERE a.id=$1`,[req.params.id]);
    if(!r.rowCount) return res.status(404).json({error:"المحاولة غير موجودة"});
    const a=r.rows[0];
    const expiresAt=new Date(new Date(a.started_at).getTime()+a.duration_minutes*60000);
    res.json({attemptId:a.id,studentName:a.student_name,startedAt:a.started_at,expiresAt,submittedAt:a.submitted_at,score:a.score,total:a.total_points,percentage:Number(a.percentage),reason:a.submit_reason,examSlug:a.slug,examTitle:a.title});
  }catch(e){res.status(500).json({error:"تعذر تحميل المحاولة: "+e.message});}
});

app.post("/api/attempts/:id/answers", async (req,res)=>{
  try{
    await ensureSchema();
    const r=await pool.query("SELECT id,exam_id,submitted_at FROM attempts WHERE id=$1",[req.params.id]);
    if(!r.rowCount || r.rows[0].submitted_at) return res.status(400).json({error:"المحاولة منتهية"});
    const answers=req.body?.answers && typeof req.body.answers==="object"?req.body.answers:{};
    const qs=await pool.query("SELECT id FROM questions WHERE exam_id=$1",[r.rows[0].exam_id]);
    const client=await pool.connect();
    try{
      await client.query("BEGIN");
      for(const q of qs.rows) if(Object.prototype.hasOwnProperty.call(answers,String(q.id)))
        await client.query(`INSERT INTO attempt_answers(attempt_id,question_id,answer) VALUES($1,$2,$3)
          ON CONFLICT(attempt_id,question_id) DO UPDATE SET answer=EXCLUDED.answer,updated_at=NOW()`,[req.params.id,q.id,String(answers[q.id]).slice(0,300)]);
      await client.query("COMMIT");
    }catch(e){try{await client.query("ROLLBACK")}catch{} throw e}finally{client.release()}
    res.json({ok:true});
  }catch(e){res.status(500).json({error:"تعذر حفظ الإجابات: "+e.message});}
});

app.post("/api/attempts/:id/submit", async (req,res)=>{
  const client=await pool.connect();
  try{
    await ensureSchema(); await client.query("BEGIN");
    const a=await client.query(`SELECT a.*,e.duration_minutes FROM attempts a JOIN exams e ON e.id=a.exam_id WHERE a.id=$1 FOR UPDATE`,[req.params.id]);
    if(!a.rowCount) throw new Error("المحاولة غير موجودة");
    if(a.rows[0].submitted_at){await client.query("ROLLBACK");return res.json({already:true,score:a.rows[0].score,total:a.rows[0].total_points,percentage:Number(a.rows[0].percentage)});}
    const attempt=a.rows[0],answers=req.body?.answers&&typeof req.body.answers==="object"?req.body.answers:{};
    const qs=await client.query("SELECT id,correct_answer,points FROM questions WHERE exam_id=$1",[attempt.exam_id]);
    let score=0,total=0;
    for(const q of qs.rows){total+=q.points;const answer=answers[String(q.id)];if(answer!==undefined){await client.query(`INSERT INTO attempt_answers(attempt_id,question_id,answer) VALUES($1,$2,$3) ON CONFLICT(attempt_id,question_id) DO UPDATE SET answer=EXCLUDED.answer,updated_at=NOW()`,[attempt.id,q.id,String(answer).slice(0,300)]);if(String(answer)===String(q.correct_answer))score+=q.points;}}
    const now=new Date(),expires=new Date(new Date(attempt.started_at).getTime()+attempt.duration_minutes*60000),reason=now>=expires?"timeout":"manual",percentage=total?Number((score/total*100).toFixed(2)):0;
    await client.query(`UPDATE attempts SET submitted_at=NOW(),submit_reason=$1,score=$2,total_points=$3,percentage=$4 WHERE id=$5`,[reason,score,total,percentage,attempt.id]);
    const review=await client.query(`SELECT q.position,q.question_text,q.options,q.correct_answer,COALESCE(aa.answer,'') AS student_answer,q.points
      FROM questions q LEFT JOIN attempt_answers aa ON aa.question_id=q.id AND aa.attempt_id=$1
      WHERE q.exam_id=$2 ORDER BY q.position`,[attempt.id,attempt.exam_id]);
    const details=review.rows.map(q=>({
      number:q.position,
      question:q.question_text,
      options:q.options,
      studentAnswer:q.student_answer,
      correctAnswer:q.correct_answer,
      correct:String(q.student_answer)===String(q.correct_answer),
      unanswered:!q.student_answer,
      points:q.points
    }));
    await client.query("COMMIT"); res.json({score,total,percentage,reason,details});
  }catch(e){try{await client.query("ROLLBACK")}catch{}res.status(500).json({error:"تعذر تسليم الامتحان: "+e.message});}finally{client.release()}
});

app.get("*",(req,res)=>{if(req.path.startsWith("/api/"))return res.status(404).end();if(req.path.startsWith("/admin"))return res.sendFile(path.join(__dirname,"public/admin.html"));if(req.path.startsWith("/exam/"))return res.sendFile(path.join(__dirname,"public/exam.html"));res.sendFile(path.join(__dirname,"public/index.html"));});

module.exports=app;
